export const changeAddress = (address) => {
    return {
      type: 'CHANGE_ADDRESS',
      payload: address
    }
  }